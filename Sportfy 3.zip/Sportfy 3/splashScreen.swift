//
//  SplashScreen.swift
//  sportfy
//
//  Created by Turma01-6 on 15/03/24.
//

import SwiftUI

struct SplashScreen: View {
    @State var isActive = false
    @State private var opacity = 0.5
    @State private var scale = CGSize(width: 1, height: 1)
    var body: some View {
        if isActive{
            ContentView()
        }else{
            ZStack{
                Color.azulEscuro.ignoresSafeArea()
                Image("sportfy-loog").resizable().scaledToFit()
                    .opacity(opacity)
                    .frame(width: 1000, height: 350)
            }.scaleEffect(scale).onAppear {
                withAnimation(.easeIn(duration: 2.2)){
                    self.opacity = 1.00
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    self.opacity = 0
                    withAnimation {
                        self.isActive = true
                    }
                }
            }
        }
    }
}

#Preview {
    SplashScreen()
}
