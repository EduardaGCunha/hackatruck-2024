//
//  map.swift
//  Sportefy
//
//  Created by Turma01-6 on 19/03/24.
//

import SwiftUI
import MapKit

struct map: View {
    @StateObject var viewModel = ViewModel()
    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: -25.518212, longitude: -54.5699713), span: MKCoordinateSpan(latitudeDelta: 0.09, longitudeDelta: 0.09))
    
    var body: some View {
        ZStack{
            Color.azulEscuro.ignoresSafeArea()
            VStack{
                Text("Quadras Proximas").font(.system(size: 30)).fontWeight(.bold).foregroundStyle(.white)
                Map(coordinateRegion: $region, annotationItems: viewModel.chars){ anotation in
                    MapPin(coordinate: CLLocationCoordinate2D(latitude: anotation.latitude, longitude: anotation.longitude)
                    )
                }
                
            }
        }.onAppear(){
            viewModel.fetch()
        }
    }
}

#Preview {
    map()
}
