import SwiftUI

struct View1: View {
    @State private var searchText = ""
    @StateObject var viewModel = ViewModel()


    var body: some View {
        NavigationStack {
            ZStack {
                // Fundo Azul
                Color.azulEscuro
                    .edgesIgnoringSafeArea(.all)
                
                VStack {
                    // Campo de busca
                    TextField("Search", text: $searchText)
                        .padding()
                        .border(Color.yellow, width: 3)
                        .background(Color.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                    
                    // Lista de quadras
                    ScrollView {
                        
                        ForEach(viewModel.chars, id: \.id) { quadra in
                            NavigationLink (destination: Detalhes(selected: quadra)) {
                                VStack {
                                    VStack {
                                        ScrollView(.horizontal, showsIndicators: false) {
                                            HStack(spacing: 10) {
                                                ForEach(quadra.fotos!, id: \.self) { foto in
                                                    AsyncImage(url: URL(string: foto)) { phase in
                                                        switch phase {
                                                        case .empty:
                                                            ProgressView()
                                                        case .success(let image):
                                                            image
                                                                .resizable()
                                                                .scaledToFill()
                                                                .frame(width: 400, height:300)
                                                                .cornerRadius(10)
                                                        case .failure:
                                                            Text("Failed to load")
                                                        @unknown default:
                                                            EmptyView()
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        HStack {
                                            Text(quadra.nome).font(.title2)
                                                .foregroundColor(.white)
                                            Spacer()
                                            
                                            Button(action: {
                                                if let index = viewModel.chars.firstIndex(where: { $0.nome == quadra.nome }) {
                                                    viewModel.chars[index].isFavorite.toggle()
                                                }
                                            }) {
                                                Image(systemName: quadra.isFavorite ? "heart.fill" : "heart")
                                                    .foregroundColor(.yellow)
                                            }
                                        }
                                        HStack {
                                            VStack{
                                                Text(quadra.bairro)
                                                    .foregroundColor(.gray)
                                                
                                                Text("R$ \(String(format: "%.2f", quadra.valorPorHora))").font(.headline).foregroundColor(.white)
                                            }
                                            Spacer()
                                        }
                                        
                                    }
                                }
                                
                            }
                            .padding()
                        }
                    }
                    .padding(.top)
                }
            }.onAppear(){
                viewModel.fetch()
            }
        }
    }
}


#Preview {
    View1()
}
