//
//  Data.swift
//  Sportefy
//
//  Created by Turma01-8 on 19/03/24.
//

import SwiftUI

struct Dataehora : View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Dataehora()
}
