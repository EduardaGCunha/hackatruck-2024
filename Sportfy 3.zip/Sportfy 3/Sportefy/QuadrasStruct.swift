//
//  QuadrasStruct.swift
//  Sportefy
//
//  Created by Turma01-10 on 18/03/24.
//

import Foundation


import SwiftUI

struct Quadra: Identifiable, Decodable {
    var _id: String
    var id: String
    var nome: String
    var bairro: String
    var fotos: [String]?
    var valorPorHora: Double
    var isFavorite: Bool 
    var latitude: Double
    var longitude: Double
    var esportes: [String]
}

