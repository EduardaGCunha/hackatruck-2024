//
//  Detalhes.swift
//  Sportefy
//
//  Created by Turma01-8 on 19/03/24.
//
import Foundation
import SwiftUI

struct Detalhes: View {
    let selected : Quadra
    @State private var showingSheet = false
    
    
    
    var body: some View {
        
        
        
        ZStack {
            
            Color.azulEscuro.ignoresSafeArea()
            
            ScrollView {
                
                
                VStack{
                    ScrollView(.horizontal, showsIndicators: false) {
                    HStack{
                        
                        ForEach(selected.fotos!, id: \.self){ foto in
                            
                                
                                AsyncImage(url: URL(string: foto )){ image in
                                    image
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(maxHeight: 200)
                                        
                                    
                                } placeholder: {
                                    Color.gray
                                }
                            }
                        }
                    }
                    
                    Text (selected.nome)
                        .multilineTextAlignment(.leading)
                    
                    //                        Text (selected.("\(valorPorHora)"))
                    //                            .multilineTextAlignment(.leading)
                    
                    Text ("loren ipsun")
                    
                    Rectangle().fill(.white).frame(width: 400, height: 10).cornerRadius(10)
                    
                    
                    Spacer()
                    Button("Check Habilities") {
                        
                        showingSheet.toggle()
                        
                    }
                    .sheet(isPresented: $showingSheet) {
                        //Dataehora()
                    }
                    
                }
                
            } .buttonStyle(.borderedProminent)
                .foregroundColor(.white)
        }
        
        
        
        
    }
}

#Preview {
    Detalhes(selected: Quadra(_id: "", id: "", nome: "", bairro: "", fotos: [
        "https://lh3.googleusercontent.com/gps-proxy/ALd4DhF9aVTJYINQZJg9kE5RYyZ0I_7EhqfpnmuQkZFQUmSpOZhv4Pe8NF-kYOur4H2uFktn-kAZ9h7JakpAHvFzpwDcRK_pF-2gFq8Zh7JoBFfpJye_fCCS2o6lH6sgyXNc3YBENjglSk39WE8ZCmvVZTMpydoHf75hVsRdVraPATcTzWgLcAAUyBRPAfEU_Af-fZD1qzc=w203-h114-k-no",
        "https://lh5.googleusercontent.com/p/AF1QipNzhqao0KG9hNTTV-pG7ZdyifcMXuLe5K5Ot68=s812-k-no",
        "https://scontent.ftow4-1.fna.fbcdn.net/v/t39.30808-6/280662813_120139687352638_4714990723957006145_n.jpg?_nc_cat=106&ccb=1-7&_nc_sid=5f2048&_nc_ohc=hmVy6xdNzCoAX-zPWKK&_nc_ht=scontent.ftow4-1.fna&oh=00_AfAE1FukEDPVipHBSg0mYumaBuW_u-vhyn9DVQn37jGy0A&oe=65FF030D"
        ], valorPorHora: 0.0, isFavorite: false, latitude: 0.0, longitude: 0.0, esportes: [""]))
}
