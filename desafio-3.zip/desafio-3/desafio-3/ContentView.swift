//
//  ContentView.swift
//  desafio-3
//
//  Created by Turma01-6 on 23/02/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            Text("hello")
        }
    }
}

#Preview {
    ContentView()
}
