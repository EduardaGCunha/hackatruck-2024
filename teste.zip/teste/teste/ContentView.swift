//
//  ContentView.swift
//  teste
//
//  Created by Turma01-6 on 23/02/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HStack{
                Circle().fill(.gray).frame(width: 100, height: 100)
                //Image(systemName: "globe").resizable().aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/).frame(width: 80, height: 80).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                VStack{
                    VStack{
                        HStack{
                            VStack{
                                Text("8").fontWeight(.heavy)
                                Text("Posts")
                                
                            }
                            Spacer()
                            VStack{
                                Text("12K").fontWeight(.heavy)
                               Text("Followers")
                            }
                            Spacer()
                            VStack{
                                Text("2K").fontWeight(.heavy)
                                Text("Following")
                            }
                        }
                        .padding()
                        Button(action: {}) {
                            Text("Edit Profile                                ").foregroundColor(.black).fontWeight(.bold)
                        }.padding().background(Color(red: 0.87, green: 0.87, blue: 0.87))
                            .cornerRadius(10)
                    }
                }
            }
        }.padding()
        VStack{
            HStack{
                Text("Nome Sobrenome").fontWeight(.bold)
                Spacer()
            }.padding(.horizontal, 20)
            HStack{
                Text("hahahahahaa ficarei maluca")
                Spacer()
            }.padding(.horizontal, 20)
        }.padding(.bottom, 20)
        Spacer()
        HStack{
            
            Image(systemName: "globe").foregroundColor(.black).padding(.horizontal, 50)
            
            Image(systemName: "globe").foregroundColor(.gray).padding(.horizontal, 50)
            
            Image(systemName: "globe").foregroundColor(.gray).padding(.horizontal, 50)
            
        }
        Spacer()
        Spacer()
        VStack{
            HStack{
                Rectangle().fill(.gray)
                Rectangle().fill(.gray)
                Rectangle().fill(.gray)
            }
            Spacer()
            HStack{
                Rectangle().fill(.gray)
                Rectangle().fill(.gray)
                Rectangle().fill(.gray)
            }
            Spacer()
            HStack{
                Rectangle().fill(.gray)
                Rectangle().fill(.gray)
                Rectangle().fill(.gray)
            }
        }
    }
}

#Preview {
    ContentView()
}
