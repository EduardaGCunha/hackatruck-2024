//
//  desafio_backgroundApp.swift
//  desafio-background
//
//  Created by Turma01-6 on 26/02/24.
//

import SwiftUI

@main
struct desafio_backgroundApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
