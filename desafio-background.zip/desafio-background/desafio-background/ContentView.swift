//
//  ContentView.swift
//  desafio-background
//
//  Created by Turma01-6 on 26/02/24.
//

import SwiftUI

struct ContentView: View {
    @State private var givenName: String = "Fulano"
    @State private var showingAlert = false
    var body: some View {
        ZStack{
            Image("sla").resizable().ignoresSafeArea().opacity(0.2)
            Image("truck").resizable().scaledToFit()
            Image("logo").resizable().scaledToFit().offset(CGSize(width: 10.0, height: -150.0))
            
            VStack{
                VStack{
                    Text("Bem vindo, \(givenName)!").padding(.bottom, 20).fontWeight(.bold)
                    TextField("Fulano", text: $givenName).padding(.leading, 160)
                }
                Spacer()
                Button("Entrar"){
                    showingAlert = true
                }.alert("ALERTA!", isPresented: $showingAlert) {
                    Button("Ok"){}
                } message: {
                    Text("nn sei oq nn sei oq la")
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
