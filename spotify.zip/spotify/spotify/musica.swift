//
//  musica.swift
//  spotify
//
//  Created by Turma01-6 on 29/02/24.
//

import Foundation

struct Song : Identifiable {
    var id : Int
    var name : String
    var artist : String
    var capa : String
}
