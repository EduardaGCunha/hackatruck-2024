//
//  ContentView.swift
//  spotify
//
//  Created by Turma01-6 on 29/02/24.
//

import SwiftUI

struct ContentView: View {
    @State var musicas = [
        Song(id: 1, name: "numb encore", artist: "Linkin Park", capa: "https://akamai.sscdn.co/letras/360x360/albuns/6/6/d/a/1203961638280273.jpg"),
        Song(id: 2, name: "numb encore", artist: "Linkin Park", capa: "https://upload.wikimedia.org/wikipedia/en/a/ab/Kai_-_cover.png"),
        Song(id: 3, name: "numb encore", artist: "Linkin Park", capa: "https://upload.wikimedia.org/wikipedia/en/a/ab/Kai_-_cover.png"),
        Song(id: 4, name: "numb encore", artist: "Linkin Park", capa: "https://upload.wikimedia.org/wikipedia/en/a/ab/Kai_-_cover.png")

    ]
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient(colors: [.blue, .black], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
                VStack{
                    ScrollView{
                        VStack{
                            Image("sla").resizable().frame(width: 200, height: 200).cornerRadius(3.0)
                            HStack{
                                Text("HackaFM").font(.system(size: 30)).fontWeight(.bold).foregroundStyle(.white).multilineTextAlignment(.leading)
                                Spacer()
                            }.padding(.horizontal, 30)
                            HStack{
                                Image("sla").resizable().frame(width: 40, height: 40)
                                Text("HackaSong").font(.system(size: 15)).fontWeight(.bold).foregroundStyle(.white)
                                Spacer()
                            }.padding(.horizontal, 30)
                            Spacer()
                            ForEach((musicas)){ song in
                                NavigationLink(destination: detailscreen(song: song)){
                                    HStack{
                                        AsyncImage(url: URL(string: song.capa), content: {
                                            image in
                                            image.resizable()
                                                .scaledToFit()
                                                .frame(width: 70, height: 70)
                                        }, placeholder: {
                                            ProgressView()
                                        })
                                        VStack{
                                            Text(song.name).font(.system(size: 16)).foregroundColor(.white)
                                            Text(song.artist).font(.system(size: 16)).foregroundStyle(.white)
                                        }
                                        Spacer()
                                        Image(systemName: "ellipsis").foregroundColor(.white)
                                    }.padding()
                                }
                            }
                        }
                        VStack{
                            HStack{
                                Text("Sugeridos").font(.system(size: 36)).foregroundStyle(.white).fontWeight(.bold)
                                Spacer()
                            }.padding()
                            ScrollView(.horizontal){
                                HStack{                                    Image("sla").resizable().frame(width: 150, height: 150)
                                    Image("sla").resizable().frame(width: 150, height: 150)
                                    Image("sla").resizable().frame(width: 150, height: 150)
                                    Image("sla").resizable().frame(width: 150, height: 150)
                                }
                            }
                        }
                    }
                    

                }
            }
                
        }
    }
}

#Preview {
    ContentView()
}
