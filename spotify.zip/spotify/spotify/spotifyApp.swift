//
//  spotifyApp.swift
//  spotify
//
//  Created by Turma01-6 on 29/02/24.
//

import SwiftUI

@main
struct spotifyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
