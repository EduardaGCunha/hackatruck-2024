//
//  detailscreen.swift
//  spotify
//
//  Created by Turma01-6 on 01/03/24.
//

import SwiftUI

struct detailscreen: View {
    @State var song : Song
    var body: some View {
        ZStack{
            LinearGradient(colors: [.blue, .black], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            VStack{
                Spacer()
                AsyncImage(url: URL(string: song.capa), content: {
                    image in
                    image.resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                }, placeholder: {
                    ProgressView()
                })
                
                Text(song.name).font(.system(size: 40)).foregroundStyle(.white).fontWeight(.bold)
                Text(song.artist).font(.system(size: 26)).foregroundStyle(.white)
                Spacer()
                HStack{
                    Spacer()
                    Image(systemName: "shuffle").foregroundColor(.white)
                        .font(.system(size: 30))
                    Spacer()
                    Image(systemName: "backward.end.fill").foregroundColor(.white)
                        .font(.system(size: 35))
                    Spacer()
                    Image(systemName: "play.fill").foregroundColor(.white)
                        .font(.system(size: 50))
                    Spacer()
                    Image(systemName: "forward.end.fill").foregroundColor(.white)
                        .font(.system(size: 35))
                    Spacer()
                    Image(systemName: "repeat").foregroundColor(.white)
                        .font(.system(size: 30))
                    Spacer()

                }
                Spacer()
            }
            
        }
    }
}

#Preview {
    detailscreen(song:
                    Song(id: 1, name: "ablbule", artist: "das ideia", capa: "https://akamai.sscdn.co/letras/360x360/albuns/6/6/d/a/1203961638280273.jpg")
    )
}
