//
//  addQuadra.swift
//  sportfy
//
//  Created by Turma01-6 on 18/03/24.
//

import SwiftUI

struct addQuadra: View {
    @State var start = Date.now
    @State var end = Date.now
    @State private var name : String = ""
    @State private var value : String = ""
    @State private var description : String = ""
    @State private var rua : String = ""
    @State private var numero : String = ""
    
    var body: some View {
        NavigationStack{
            ZStack{
                Color.azulEscuro.ignoresSafeArea()
                ScrollView{
                    NavigationLink(destination: ContentView()){
                        HStack{
//                            Image(systemName: "backarrow)
                            Text("Voltar")
                                .colorInvert().padding(.leading, 20)
                            Spacer()
                        }
                    }
                    VStack{
                        Text("Adicione uma Quadra!").font(.system(size: 35)).foregroundStyle(.white).fontWeight(.bold).padding(.bottom, 15)
                        HStack{
                            Text("Nome:").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.leading, 10)
                            
                            Spacer()
                        }.padding(.top, 5)
                        ZStack{
                            Rectangle().fill(.yellow).frame(width: 350, height: 50).cornerRadius(10)
                            Rectangle().fill(.white).frame(width: 340, height: 45).cornerRadius(10)
                            TextField("Nome", text: $name).padding(.leading, 25)
                        }
                        
                        HStack{
                            Text("Valor por Hora:").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.leading, 10)
                            Spacer()
                        }
                        ZStack{
                            Rectangle().fill(.yellow).frame(width: 350, height: 50).cornerRadius(10)
                            Rectangle().fill(.white).frame(width: 340, height: 45).cornerRadius(10)
                            TextField("R$ 70,00", text: $value).padding(.leading, 25)
                            
                        }
                        
                        HStack{
                            Text("Horarios disponiveis").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.leading, 10)
                            Spacer()
                        }
                        HStack{
                            Text("Inicio").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.leading, 10)
                            ZStack{
                                Rectangle().fill(.white).cornerRadius(8).frame(width: 70, height: 32).offset(x: 29)
                                DatePicker("", selection: $start, displayedComponents: .hourAndMinute).accentColor(.yellow)
                                
                            }
                            Text("Fim").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.leading, 10)
                            ZStack{
                                Rectangle().fill(.white).cornerRadius(8).frame(width: 70, height: 32).offset(x: 29)
                                DatePicker("", selection: $end, displayedComponents: .hourAndMinute).accentColor(.yellow)
                            }
                            Spacer()
                        }
                    }
                    HStack{
                        Text("Descrição do local:").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.leading, 10)
                        Spacer()
                    }
                    ZStack{
                        Rectangle().fill(.yellow).frame(width: 350, height: 150).cornerRadius(10)
                        Rectangle().fill(.white).frame(width: 340, height: 145).cornerRadius(10)
                        TextField("Quadra de basquete bem localizada", text: $description).padding(.leading, 25)
                    }
                    HStack{
                        Text("Quais tipos de esporte podem ser praticados nessa quadra?").font(.system(size: 20)).fontWeight(.regular).foregroundStyle(.white).padding(.leading, 20)
                        Spacer()
                    }
                    VStack{
                        HStack{
                            ZStack{
                                Rectangle().fill(.yellow).frame(width: 20, height: 20).cornerRadius(5)
                                Rectangle().fill(.white).frame(width: 17, height: 17).cornerRadius(5)
                            }
                            Text("Basquete").font(.system(size: 20)).foregroundStyle(.white)
                            Spacer()
                        }.padding(.leading, 20)
                        HStack{
                            ZStack{
                                Rectangle().fill(.yellow).frame(width: 20, height: 20).cornerRadius(5)
                                Rectangle().fill(.white).frame(width: 17, height: 17).cornerRadius(5)
                            }
                            Text("Futebol").font(.system(size: 20)).foregroundStyle(.white)
                            Spacer()
                        }.padding(.leading, 20)
                        HStack{
                            ZStack{
                                Rectangle().fill(.yellow).frame(width: 20, height: 20).cornerRadius(5)
                                Rectangle().fill(.white).frame(width: 17, height: 17).cornerRadius(5)
                            }
                            Text("Volei").font(.system(size: 20)).foregroundStyle(.white)
                            Spacer()
                        }.padding(.leading, 20)
                        HStack{
                            ZStack{
                                Rectangle().fill(.yellow).frame(width: 20, height: 20).cornerRadius(5)
                                Rectangle().fill(.white).frame(width: 17, height: 17).cornerRadius(5)
                            }
                            Text("Outros").font(.system(size: 20)).foregroundStyle(.white)
                            Spacer()
                        }.padding(.leading, 20)
                    }
                    Spacer()
                    HStack{
                        Text("Endereco").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.bold).padding(.leading, 10)
                        Spacer()
                    }
                    HStack{
                        Text("Rua").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.leading, 10)
                        Spacer()
                        Text("N").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.trailing, 35)
                        
                    }
                    HStack{
                        Spacer()
                        ZStack{
                            Rectangle().fill(.yellow).frame(width: 290, height: 50).cornerRadius(10)
                            Rectangle().fill(.white).frame(width: 280, height: 45).cornerRadius(10)
                            TextField("Rua Pedro Pascal", text: $rua).padding(.leading, 15)
                            
                        }
                        ZStack{
                            Rectangle().fill(.yellow).frame(width: 50, height: 50).cornerRadius(10)
                            Rectangle().fill(.white).frame(width: 45, height: 45).cornerRadius(10)
                            TextField("25", text: $numero).padding(.leading, 25)
                            
                        }
                    }
                    HStack{
                        Text("Adicione uma foto:").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.leading, 10)
                        Spacer()
                    }.padding(.top, 5)
                    ZStack{
                        Rectangle().fill(.yellow).frame(width: 350, height: 50).cornerRadius(10)
                        Rectangle().fill(.white).frame(width: 340, height: 45).cornerRadius(10)
                        Image(systemName: "camera")
                    }
                    Spacer()
                    Spacer()
                    ZStack{
                        Rectangle().fill(.yellow).frame(width: 200, height: 50).cornerRadius(10)
                        Text("Adicionar!").font(.system(size: 20)).foregroundStyle(.white)
                    }
                }
            }.toolbar(.hidden, for: .tabBar)
        }
    }
}

#Preview {
    addQuadra()
}
