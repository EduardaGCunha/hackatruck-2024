//
//  ContentView.swift
//  Perfil
//
//  Created by Turma01-8 on 18/03/24.
//

import SwiftUI

struct userProfile: View {
    
    @State var nome : String = ""
    @State var email : String = ""
    @State var telefone : String = ""
    @State var estado : String = ""
    @State var cidade : String = ""
    @State var endereco : String = ""
    
    var body: some View {
        
        NavigationStack {
            ZStack {
                Color.azulEscuro.ignoresSafeArea()
                ScrollView {
                    VStack {
                        HStack{
                            Image(systemName: "pencil")
                                .foregroundColor(.white)
                                .padding(.leading, 200)
                            
                            Text("Editar Perfil")
                                .foregroundColor(.white)
                        }
                        ZStack {
                            Rectangle()
                                .stroke(.amarelo, lineWidth: 5)
                                .background(.amareloClaro)
                                .frame(width: 350, height: 200)
                                .presentationCornerRadius(100)
                                .padding(.top)
                            
                            HStack {
                                Image("avatar")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .clipShape(Circle())
                                    .frame(width: 120)
                                
                                VStack {
                                    
                                    HStack{
                                        Text("Nome:").font(.system(size:15)).foregroundStyle(.black).fontWeight(.regular)
                                            .padding(.leading, -90)
                                            .offset(y: 30)
                                    }
                                    ZStack{
                                        Rectangle().fill(.yellow).frame(width: 200, height: 30).cornerRadius(10)
                                        Rectangle().fill(.white).frame(width: 195, height: 25).cornerRadius(10)
                                        TextField("Escreva seu nome", text: $nome)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: 180, height: 40)
                                            .font(.system(size:15))
                                    }
                                    .offset(y:20)
                                    HStack{
                                        Text("E-mail:").font(.system(size:15)).foregroundStyle(.black).fontWeight(.regular)
                                            .padding(.leading, -90)
                                            .offset(y: 12)
                                        
                                    }
                                    ZStack{
                                        Rectangle().fill(.yellow).frame(width: 200, height: 30).cornerRadius(10)
                                        Rectangle().fill(.white).frame(width: 195, height: 25).cornerRadius(10)
                                        TextField("Escreva seu e-mail", text: $email)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: 180, height: 40)
                                            .font(.system(size:15))
                                    }
                                    HStack{
                                        Text("Telefone:").font(.system(size:15)).foregroundStyle(.black).fontWeight(.regular)
                                            .padding(.leading, -90)
                                            .offset(y: -5)
                                        
                                    }
                                    ZStack{
                                        Rectangle().fill(.yellow).frame(width: 200, height: 30).cornerRadius(10)
                                        Rectangle().fill(.white).frame(width: 195, height: 25).cornerRadius(10)
                                        TextField("Escreva seu telefone", text: $telefone)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: 180, height: 40)
                                            .font(.system(size:15))
                                    } .offset(y: -16)
                                    
                                    
                                    
                                }
                                
                            }
                            
                        }
                        
                        HStack{
                            Text("Estado:").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.leading, -170)
                                .offset(y:10)
                            
                        }
                        ZStack{
                            Rectangle().fill(.yellow).frame(width: 350, height: 50).cornerRadius(10)
                            Rectangle().fill(.white).frame(width: 340, height: 45).cornerRadius(10)
                            TextField("Escreva sua UF", text: $estado)
                                .frame(width: 180, height: 40)
                                .font(.system(size:20))
                                .padding(.leading, -99)
                        }
                        HStack{
                            Text("Cidade:").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.leading, -170)
                                .offset(y:10)
                            
                        }
                        ZStack{
                            Rectangle().fill(.yellow).frame(width: 350, height: 50).cornerRadius(10)
                            Rectangle().fill(.white).frame(width: 340, height: 45).cornerRadius(10)
                            TextField("Escreva sua cidade", text: $cidade)
                                .frame(width: 180, height: 40)
                                .font(.system(size:20))
                                .padding(.leading, -99)
                        }
                        HStack{
                            Text("Endereço:").font(.system(size: 20)).foregroundStyle(.white).fontWeight(.regular).padding(.leading, -170)
                                .offset(y:10)
                            
                        }
                        ZStack{
                            Rectangle().fill(.yellow).frame(width: 350, height: 50).cornerRadius(10)
                            Rectangle().fill(.white).frame(width: 340, height: 45).cornerRadius(10)
                            TextField("Escreva seu endereço", text: $endereco)
                                .frame(width: 180, height: 40)
                                .font(.system(size:18))
                                .padding(.leading, -99)
                        }
                    }
                }
            }
        }
    }
}


#Preview {
    userProfile()
}
