//
//  ContentView.swift
//  Sportefy
//
//  Created by Turma01-10 on 18/03/24.
//

import SwiftUI

struct ContentView: View {
    init() {
        UITabBar.appearance().backgroundColor = UIColor.amarelo}
    
    var body: some View {
        NavigationStack{
            TabView {
                View1().tabItem {Label("Home", systemImage: "house")}
                View1().tabItem {Label("Mapa", systemImage: "map")}
                addQuadra().tabItem {Label("", systemImage: "plus.app.fill")}
                View1().tabItem {Label("Favoritos", systemImage: "heart")}
                userProfile().tabItem {Label("Perfil", systemImage: "person")}
            }.accentColor(Color.black)
        }.toolbar(.hidden)
    }
}

#Preview {
    ContentView()
}
