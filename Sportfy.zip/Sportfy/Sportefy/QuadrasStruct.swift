//
//  QuadrasStruct.swift
//  Sportefy
//
//  Created by Turma01-10 on 18/03/24.
//

import Foundation


import SwiftUI

struct Quadra: Hashable {
    var nome: String
    var bairro: String
    var fotos: [String]
    var valorPorHora: Double
    var isFavorite: Bool 
}

