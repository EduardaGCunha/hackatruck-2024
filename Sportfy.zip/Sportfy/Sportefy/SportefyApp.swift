//
//  SportefyApp.swift
//  Sportefy
//
//  Created by Turma01-10 on 18/03/24.
//

import SwiftUI

@main
struct SportefyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
