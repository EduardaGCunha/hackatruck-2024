import SwiftUI

struct View1: View {
    @State private var searchText = ""
    @State var quadrasArray: [Quadra] = [
        Quadra(nome: "Quadra Esportiva A", bairro: "Centro", fotos: ["https://static.sportit.com.br/public/sportit/imagens/produtos/quadra-poliesportiva-piso-modular-externo-m2-2913.jpg", "https://static.sportit.com.br/public/sportit/imagens/produtos/quadra-poliesportiva-piso-modular-externo-m2-2913.jpg", "https://static.sportit.com.br/public/sportit/imagens/produtos/quadra-poliesportiva-piso-modular-externo-m2-2913.jpg"], valorPorHora: 50.00, isFavorite: false),
        Quadra(nome: "Quadra Esportiva B", bairro: "Zona Sul", fotos: ["https://lh3.googleusercontent.com/p/AF1QipOkJgoGInt8eYh3i1xPr2LWRePIv0z52mbkZzPE=s1360-w1360-h1020", "https://lh3.googleusercontent.com/p/AF1QipMZAQBB_tr67x-KyTZnk7Cx_8aTW5mrZiqhG98H=s1360-w1360-h1020", "https://lh3.googleusercontent.com/p/AF1QipP0HTL9v2o_O35ETC9A7nbhkQl-WVey8QJbSmP6=s1360-w1360-h1020"], valorPorHora: 40.00, isFavorite: false),
        Quadra(nome: "Quadra Esportiva C", bairro: "Zona Norte", fotos: ["https://lh5.googleusercontent.com/p/AF1QipM2gqxGFkkiKnsJbgoxnOCQCT8G9e6xJKeF4hMg=w408-h544-k-no", "https://lh5.googleusercontent.com/p/AF1QipOtc-AUEYDoy_oPGek0tyIKaQlPoSeQB25ce5Y=w1200-h1976-p-k-no", "https://lh5.googleusercontent.com/p/AF1QipNT4i3u57K5-HUkwNo21hVDb_7IkLVeVWxz5W4=w1200-h1976-p-k-no"], valorPorHora: 60.00, isFavorite: false)
    ]

    var body: some View {
        ZStack {
            // Fundo Azul
            Color.azulEscuro
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                // Campo de busca
                TextField("Search", text: $searchText)
                    .padding()
                    .border(Color.yellow, width: 3)
                    .background(Color.white)
                    .cornerRadius(10)
                    .padding(.horizontal)
                
                // Lista de quadras
                ScrollView {
                    
                    ForEach(quadrasArray.filter {
                        $0.nome.localizedCaseInsensitiveContains(searchText)
                        || searchText.isEmpty
                    }, id: \.self) { quadra in
                        VStack {
                            VStack {
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 10) {
                                        ForEach(quadra.fotos, id: \.self) { foto in
                                            AsyncImage(url: URL(string: foto)) { phase in
                                                switch phase {
                                                case .empty:
                                                    ProgressView()
                                                case .success(let image):
                                                    image
                                                        .resizable()
                                                        .scaledToFill()
                                                        .frame(width: 400, height:300)
                                                        .cornerRadius(10)
                                                case .failure:
                                                    Text("Failed to load")
                                                @unknown default:
                                                    EmptyView()
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                HStack {
                                    Text(quadra.nome).font(.title2)
                                        .foregroundColor(.white)
                                    Spacer()
                                    
                                    Button(action: {
                                        if let index = quadrasArray.firstIndex(where: { $0.nome == quadra.nome }) {
                                            quadrasArray[index].isFavorite.toggle()
                                        }
                                    }) {
                                        Image(systemName: quadra.isFavorite ? "heart.fill" : "heart")
                                            .foregroundColor(.yellow)
                                    }
                                }
                                HStack {
                                    VStack{
                                        Text(quadra.bairro)
                                            .foregroundColor(.gray)
                                        
                                        Text("R$ \(String(format: "%.2f", quadra.valorPorHora))").font(.headline).foregroundColor(.white)
                                    }
                                    Spacer()
                                }
                                
                                
                            }
                        }
                        .padding()
                    }
                }
                .padding(.top)
            }
        }
        .foregroundColor(.black)
    }
}


#Preview {
    View1()
}
