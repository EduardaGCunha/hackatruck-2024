//
//  calculadora_imcApp.swift
//  calculadora-imc
//
//  Created by Turma01-6 on 27/02/24.
//

import SwiftUI

@main
struct calculadora_imcApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
