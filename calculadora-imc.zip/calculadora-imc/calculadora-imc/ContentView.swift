//
//  ContentView.swift
//  calculadora-imc
//
//  Created by Turma01-6 on 27/02/24.
//

import SwiftUI

struct ContentView: View {
    @State private var weight: String = ""
    @State private var height: String = ""
    @State var zStackColor : Color? = .teal
    @State var imc : String = "IMC"
    var body: some View {
        ZStack {
            zStackColor.ignoresSafeArea()
            VStack{
                Spacer()
                Text("Calculadora de IMC").fontWeight(.bold)
                Text("Insira seu peso: ")
                TextField("Insira seu peso", text: $weight)
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .frame(width: 300)
                Text("Insira sua altura: ")
                TextField("Insira sua altura", text: $height)
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .padding()
                    .background(.gray.opacity(0.2))
                    .cornerRadius(10)
                    .frame(width: 300)
                Button("Calcular"){
                    var result : Double = Double(weight)! / pow(Double(height)!,2)
                    print(Double(height)!*Double(height)!)
                    print(result)
                    if(result <= 18.5){
                        zStackColor = Color.baixo
                        imc = "Baixo Peso"
                    }else if(result > 18.5 && result <= 24.99){
                        zStackColor = Color.normal
                        imc = "Normal"
                    }else if(result >= 25 && result <= 29.99){
                        zStackColor = Color.sobrepeso
                        imc = "Sobrepeso"
                    }else{
                        zStackColor = Color.obesidade
                        imc = "Obesidade"
                    }
                }.frame(width: 250).foregroundColor(.white).background(.blue).buttonStyle(.borderedProminent)
                    .clipShape(Capsule())
                Spacer()
                Text(imc).foregroundStyle(.white).font(.system(size: 40))
                Spacer()
                Image("tabela-IMC").resizable().scaledToFit()
            }
        }
    }
}

#Preview {
    ContentView()
}
