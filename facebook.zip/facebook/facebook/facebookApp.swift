//
//  facebookApp.swift
//  facebook
//
//  Created by Turma01-6 on 26/02/24.
//

import SwiftUI

@main
struct facebookApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
