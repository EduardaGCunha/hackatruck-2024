//
//  ContentView.swift
//  facebook
//
//  Created by Turma01-6 on 26/02/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            ZStack{
                Rectangle().fill(.blue)
                Rectangle().fill(.white).offset(CGSize(width: 0, height: 250.0))
                ZStack{
                    VStack{
                        ZStack{
                            Circle().fill(.white).frame(width: 170, height: 170)
                            Circle().fill(.blue).frame(width: 160, height: 160)
                            Circle().fill(.gray).frame(width: 150, height: 150)
                            Image.init(systemName: "camera").foregroundColor(.white).font(.system(size:60))
                        }
                        Text("Your Name").fontWeight(.bold)
                        Text("100k friends")
                        HStack{
                            ZStack{
                                Circle().fill(.gray).frame(width: 28, height: 30)
                                Image.init(systemName: "person").foregroundColor(.white)
                            }
                            ZStack{
                                Circle().fill(.gray).frame(width: 28, height: 30)
                                Image.init(systemName: "person").foregroundColor(.white)
                            }
                            ZStack{
                                Circle().fill(.gray).frame(width: 28, height: 30)
                                Image.init(systemName: "person").foregroundColor(.white)
                            }
                            ZStack{
                                Circle().fill(.gray).frame(width: 28, height: 30)
                                Image.init(systemName: "person").foregroundColor(.white)
                            }
                        }.padding(.top, 5)
                        HStack{
                            Button("Add to Story"){
                                
                            }
                            .frame(width:250).background(.blue)
                            .foregroundColor(.white).buttonStyle(.borderedProminent).clipShape(Capsule())
                            Button("..."){
                                
                            }
                            .frame(width: 70)
                            .foregroundColor(.white).background(.gray).buttonStyle(.borderedProminent).clipShape(Capsule()).tint(.gray)
                        }
                        VStack{
                            HStack{
                                Image.init(systemName: "globe")
                                Text("nn sei oq nn sei oq la")
                            }
                            HStack{
                                Image.init(systemName: "globe")
                                Text("nn sei oq nn sei oq la")
                            }
                            HStack{
                                Image.init(systemName: "globe")
                                Text("nn sei oq nn sei oq la")
                            }
                            HStack{
                                Image.init(systemName: "globe")
                                Text("nn sei oq nn sei oq la")
                                
                            }
                        }
                    }
                }
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
