//
//  d2.swift
//  Aula01
//
//  Created by Turma01-6 on 23/02/24.
//

import SwiftUI

struct d2: View {
    var body: some View {
        VStack{
            HStack{
                Spacer()
                Image("exo-kai").resizable().aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/).frame(width: 100, height:100).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                Spacer()
                VStack(spacing: 10){
                    Text("Hackatruck")
                        .foregroundColor(.red)
                    Text("77 universidades")
                        .foregroundColor(.blue)
                    Text("9 regioes do Brasil")
                        .foregroundColor(.yellow)
                }
                Spacer()
            }
        }
    }
}

#Preview {
    d2()
}
