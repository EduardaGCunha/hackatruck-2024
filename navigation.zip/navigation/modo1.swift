//
//  modo1.swift
//  navigation
//
//  Created by Turma01-6 on 29/02/24.
//

import SwiftUI

struct modo1: View {
    var body: some View {
        ZStack{
            Color.blue.ignoresSafeArea()
            VStack{
                Text("Modo 1")
                Spacer()
                ZStack{
                    RoundedRectangle(cornerRadius: 20).fill(.pink).frame(width: 300, height: 200)
                    Text("nn sei oq\nnn sei oq la\nnn sei oq la\nn sei aquilo outro")
                    
                }
            }
        }
    }
}

#Preview {
    modo1()
}
