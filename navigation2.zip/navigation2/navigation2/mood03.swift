//
//  mood03.swift
//  navigation2
//
//  Created by Turma01-6 on 29/02/24.
//

import SwiftUI

struct mood03: View {
    @State var name : String
    var body: some View {
        ZStack{
            Color.black.ignoresSafeArea()
            Rectangle().fill(.pink).frame(width: 300, height: 250).cornerRadius(20)
            Text("Obrigada, \(name)")
            
        }
    }
}

#Preview {
    mood03(name: String())
}
