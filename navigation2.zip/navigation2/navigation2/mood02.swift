//
//  modo01.swift
//  navigation2
//
//  Created by Turma01-6 on 29/02/24.
//

import SwiftUI

struct mood02: View {
    @State var nome : String = "eduarda"
    var body: some View {
        ZStack{
            Color.black.ignoresSafeArea()
            VStack{
                Text("Modo 02").fontWeight(.bold).font(.system(size: 30)).foregroundStyle(.white)
                Spacer()
                ZStack{
                    Rectangle().fill(.pink).frame(width: 300, height: 200).cornerRadius(10.0)
                    VStack{
                        Text("Insira seu nome sla")
                        TextField("Fulano", text: $nome).padding(.leading, 170)
                        NavigationLink("Entrar", destination: mood03(name: nome)).navigationTitle("omg")
                    }
                }
                Spacer()
                
            }
        }
    }
}

#Preview {
    mood02()
}
