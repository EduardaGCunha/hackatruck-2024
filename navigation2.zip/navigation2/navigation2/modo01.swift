//
//  modo01.swift
//  navigation2
//
//  Created by Turma01-6 on 29/02/24.
//

import SwiftUI

struct modo01: View {
    var body: some View {
        ZStack{
            Color.black.ignoresSafeArea()
            VStack{
                Text("Modo 01").fontWeight(.bold).font(.system(size: 30)).foregroundStyle(.white)
                Spacer()
                ZStack{
                    Rectangle().fill(.pink).frame(width: 300, height: 200).cornerRadius(10.0)
                    Text("nn sei oq\nnn sei oq la\nnn sei oq la\nn sei oq").foregroundStyle(.white)
                }
                Spacer()
                
            }
        }
    }
}

#Preview {
    modo01()
}
