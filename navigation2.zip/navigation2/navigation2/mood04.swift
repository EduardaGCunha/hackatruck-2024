//
//  mood04.swift
//  navigation2
//
//  Created by Turma01-6 on 29/02/24.
//

import SwiftUI

struct mood04: View {
    var body: some View {
        ZStack{
            Color.blue.ignoresSafeArea()
            VStack{
                Text("Sheet View").foregroundStyle(.white).font(.system(size: 30))
                Spacer()
                ZStack{
                    Rectangle().fill(.pink).frame(width: 300, height: 300).cornerRadius(20)
                    Text("hello hiiiii omg is that\nA STALKER")
                }
                
            }
        }
    }
}

#Preview {
    mood04()
}
