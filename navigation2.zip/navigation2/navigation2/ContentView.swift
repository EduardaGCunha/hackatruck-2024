//
//  ContentView.swift
//  navigation2
//
//  Created by Turma01-6 on 29/02/24.
//

import SwiftUI

struct ContentView: View {
    @State var isPresented : Bool = false
    var body: some View {
        NavigationStack{
            ZStack{
                Color.black.ignoresSafeArea()
                VStack {
                    Image("logo").resizable().scaledToFit()
                    Spacer()
                    NavigationLink("Modo 01", destination: modo01())
                        .navigationTitle("omg")
                   // Button("Modo 02"){
                        
                    //}.alert()
                    
                    NavigationLink("Modo 02", destination: mood02()).navigationTitle("omg")
                    Button("Modo 03"){
                        isPresented = !isPresented
                    }.sheet(isPresented: $isPresented, content: {
                        mood04()
                    })
                    Spacer()
                }
                .padding()
            }
        }
    }
}

#Preview {
    ContentView()
}
