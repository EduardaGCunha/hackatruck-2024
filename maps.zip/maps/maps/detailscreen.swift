//
//  detailscreen.swift
//  maps
//
//  Created by Turma01-6 on 04/03/24.
//

import SwiftUI
import MapKit

struct detailscreen: View {
    @State var location : Location
    var body: some View {
        VStack{
            Text(location.name).font(.system(size: 30))
            AsyncImage(url: URL(string: location.flag), content: {
                image in
                image.resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200)
            }, placeholder: {
                ProgressView()
            })
            Text(location.description)
        }
    }
}

#Preview {
    detailscreen(location: Location(name: "Foz do Iguacu", coordinate: CLLocationCoordinate2D(latitude: -25.526592, longitude: -54.5836063), flag: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/Bras%C3%A3o_de_Armas_do_Munic%C3%ADpio_de_Foz_do_Igua%C3%A7u.svg/1280px-Bras%C3%A3o_de_Armas_do_Munic%C3%ADpio_de_Foz_do_Igua%C3%A7u.svg.png", description: "Foz do Iguaçu é um município brasileiro localizado na região oeste do estado do Paraná. A distância rodoviária até Curitiba, capital administrativa estadual, é de 643 quilômetros.[1] Sua área territorial é de 617,701 km², dos quais 61,200 km² estão em perímetro urbano,[7] e sua população, conforme o censo de 2022, é de 285 415 habitantes." )
    )
}
