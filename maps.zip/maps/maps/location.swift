//
//  location.swift
//  maps
//
//  Created by Turma01-6 on 04/03/24.
//
import MapKit
import Foundation

struct Location: Identifiable {
    let id = UUID();
    let name : String
    let coordinate : CLLocationCoordinate2D
    let flag : String
    let description : String
}
