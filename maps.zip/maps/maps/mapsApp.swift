//
//  mapsApp.swift
//  maps
//
//  Created by Turma01-6 on 04/03/24.
//

import SwiftUI

@main
struct mapsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
