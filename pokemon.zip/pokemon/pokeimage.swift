//
//  pokeimage.swift
//  pokemon
//
//  Created by Turma01-6 on 06/03/24.
//

import SwiftUI

struct pokeimage: View {
    @StateObject var vm = PokeApi()
    @State var url : String
    
    var body: some View {
        VStack{
            AsyncImage(url: URL(string:  vm.sprite.front_default), content: {
                image in
                image.resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 300)
            }, placeholder: {
                ProgressView()
            })
        }.onAppear(){
            vm.fetchByPokemon(url2: url)
        }
    }
}

#Preview {
    pokeimage(url: "https://pokeapi.co/api/v2/pokemon/1/")
}
