//
//  pokemon.swift
//  pokemon
//
//  Created by Turma01-6 on 05/03/24.
//

import Foundation

struct Pokemon : Decodable {
    var results : [PokemonEntry]
}
struct PokemonEntry : Decodable {
    var name : String
    var url : String
}

struct PokemonInfo : Decodable {
    var sprites : PokemonSprite?
    var weight : Int?
}

struct PokemonSprite : Decodable {
    var front_default : String
}

struct PokeInteiro : Decodable {
    var name : String
    var front_default : String
}

