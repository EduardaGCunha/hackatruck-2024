//
//  viewmodel.swift
//  pokemon
//
//  Created by Turma01-6 on 05/03/24.
//

import Foundation

class PokeApi : ObservableObject {
    
    @Published var poke : [PokemonEntry] = []
    @Published var sprite : PokemonSprite = PokemonSprite(front_default: "https://m.media-amazon.com/images/I/61NMSffoXfL.jpg")
    func fetch(){
        guard let url = URL(string: "https://pokeapi.co/api/v2/pokemon/?offset=0&limit=151") else {
            return
        }
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else{return}
            do {
                let parsed = try JSONDecoder().decode(Pokemon.self, from: data)
                DispatchQueue.main.async {
                    self?.poke = parsed.results
                }
            }catch{
                print(error)
            }
        }
        task.resume()
    }
    
    func fetchByPokemon(url2 : String){
        guard let url = URL(string: url2) else {
            return
        }
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else{return}
            do {
                //let parsed = try JSONDecoder().decode(Pokemon.self, from: data)
                let pokemonSprite = try! JSONDecoder().decode(PokemonInfo.self, from: data)
                DispatchQueue.main.async {
                    self?.sprite = pokemonSprite.sprites!
                }
            }
        }
        task.resume()
    }
}
