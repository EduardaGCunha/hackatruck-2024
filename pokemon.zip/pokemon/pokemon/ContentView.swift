//
//  ContentView.swift
//  pokemon
//
//  Created by Turma01-6 on 05/03/24.
//

import SwiftUI

struct ContentView: View {
    @StateObject var vm = PokeApi()
    var body: some View {
        NavigationStack{
            VStack{
                List(Array(vm.poke.enumerated()), id: \.offset){ i, p in
                    NavigationLink(destination: pokeimage(url: p.url)){
                        AsyncImage(url: URL(string:  "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/\(i+1).png"), content: {
                            image in
                            image.resizable()
                                .scaledToFit()
                                .frame(width: 70, height: 70)
                        }, placeholder: {
                                ProgressView()
                        })
                        Text(p.name).foregroundStyle(.black)
                    }
                }
            }
        }.onAppear(){
            vm.fetch()
        }
    }
}

#Preview {
    ContentView()
}
