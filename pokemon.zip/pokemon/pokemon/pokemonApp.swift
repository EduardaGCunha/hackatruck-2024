//
//  pokemonApp.swift
//  pokemon
//
//  Created by Turma01-6 on 05/03/24.
//

import SwiftUI

@main
struct pokemonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
