//
//  tela2.swift
//  tabview
//
//  Created by Turma01-6 on 28/02/24.
//

import SwiftUI

struct tela2: View {
    let colors : [Color] = [.blue, .green, .yellow, .brown, .orange, .black]
    var body: some View {
        ZStack{
            Color.red.ignoresSafeArea()
            ScrollView{
                Text("TITULO 02").foregroundStyle(.white)
                ForEach(Array(colors.enumerated()), id: \.offset){i, c in
                    HStack{
                        VStack{
                            Rectangle().fill(c).frame(width: 200, height: 150)
                        }
                        VStack{
                            Text("TEXTO").foregroundStyle(.white)
                            Text("nn sei \(i+1)").foregroundStyle(.white)
                            Text("nn sei oq la").foregroundStyle(.white)
                        }
                        
                    }
                }
            }
        }
    }
}

#Preview {
    tela2()
}
