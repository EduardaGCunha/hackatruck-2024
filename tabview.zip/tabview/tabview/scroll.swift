//
//  scroll.swift
//  tabview
//
//  Created by Turma01-6 on 28/02/24.
//

import SwiftUI

struct scroll: View {
    var body: some View {
            ZStack{
                Color.teal.ignoresSafeArea()
                ScrollView{
                    Text("Titulo 01").foregroundStyle(.white)
                    ForEach((1...10), id:\.self){_ in
                        VStack{
                            Rectangle().fill(.white).frame(width: 300, height: 150)
                            Spacer()
                            Text("TESTE").foregroundStyle(.white)
                        }
                    }
                }
            }
    }
}

#Preview {
    scroll()
}
