//
//  tela3.swift
//  tabview
//
//  Created by Turma01-6 on 28/02/24.
//

import SwiftUI

struct tela3: View {
    var body: some View {
        VStack{
            Text("Titulo 02")
            List((1...20), id: \.self){r in
                Text("omg \(r)")
            }
        }
    }
}

#Preview {
    tela3()
}
