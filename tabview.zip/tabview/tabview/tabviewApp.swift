//
//  tabviewApp.swift
//  tabview
//
//  Created by Turma01-6 on 28/02/24.
//

import SwiftUI

@main
struct tabviewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
