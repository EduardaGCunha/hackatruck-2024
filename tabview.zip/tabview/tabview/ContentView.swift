//
//  ContentView.swift
//  tabview
//
//  Created by Turma01-6 on 28/02/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            tela2().tabItem {
                Label("Menu", systemImage: "person")
            }
            scroll().tabItem{
                Label("Scroll", systemImage: "person")
            }
            tela3().tabItem{
                Label("omg", systemImage: "person")
            }
        }
    }
}

#Preview {
    ContentView()
}
